-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2020 at 01:03 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(200) NOT NULL,
  `admnumber` varchar(200) NOT NULL,
  `year` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `hostel` varchar(200) NOT NULL,
  `occupation` varchar(200) NOT NULL,
  `residence` varchar(200) NOT NULL,
  `town` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `dob` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `image`, `admnumber`, `year`, `address`, `hostel`, `occupation`, `residence`, `town`, `username`, `dob`) VALUES
(1, 'Nickline Omuyonga', 'nickomuyonga@gmail.com', '$2y$10$qEOYqFjpFQeD7T2XVD1fKe3rL4NNRa3UYqJ9nLljp.I3RjKNLjA4K', 'IMG_20200210_153111.jpg', '6726', '2016', 'Eldoret', 'Jaramogi', 'Electrician', 'Racecourse', 'Eldoret', 'samorein', '1999-02-02'),
(2, 'Moses Kuria', 'nickomuyonga2@gmail.com', '$2y$10$WMnTGy2NUlpmPr9nHIAK6.Of03ly.ZBgkaCd5PNqDreYBG1paXZrC', 'IMG_20190412_111009.jpg', '67564', '2010', 'Karen', 'Olang', 'Engineer', 'Nairobi', 'Embakasi', 'Babayao', '1997-01-02'),
(3, 'James Bond', 'test@gmail.com', '$2y$10$PrEMUcfAgI7ubxILCt6D8uVXh25NtWsQdVllgb5mWYewILgfcjpC2', 'hey.jpg', '56654', '2015', 'Eldoret', 'Ouko', 'Nurse', 'Nakuru', 'Nakuru', 'samorein', '1996-12-04'),
(4, 'Ibrahim Bii', 'ibrahim@gmail.com', '$2y$10$TmIjXkzwh2rGPsZnfAS3aerPYsrERef5FiyakhtISA97F.8dQQbHm', 'IMG_20190404_125234.jpg', '67543', '2018', 'Mombasa', 'Bowers', 'Computer Scientist', 'Changamwe', 'Majengo', 'Hazrdmaneo', '1996-03-09'),
(5, 'Martin Too', 'testuser@gmail.com', '$2y$10$w6kDiSSsBLH3HhKJ9Lz0Ceha2XoS8beYik8hcIlljmqtkI6cY/BbG', 'IMG_20190412_111051.jpg', '657465', '2016', 'Malindi', 'Amadi', 'Doctor', 'Maral', 'Kericho', 'nickoiuy', '1998-03-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
